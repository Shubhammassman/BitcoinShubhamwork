﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.ComponentModel.DataAnnotations;

namespace BitCoinMassman.Models
{
    public class WebViewModel
    {

        [Required]
        [Display(Name = "IBitCoinsId")] 
        public string BitCoinsId { get; set; }

        

        [Required]
        [Display(Name = "CurrencyId")]
        public string CurrencyId { get; set; }



        [Required]
        [Display(Name = "BitCoins")]
        public string BitCoins { get; set; }


        [Required]
        [Display(Name = "Currency ")]
        public string Currency { get; set; }


        [Required]
        [Display(Name = "Grossvalue ")]
        public string Grossvalue { get; set; }
        

    }
}