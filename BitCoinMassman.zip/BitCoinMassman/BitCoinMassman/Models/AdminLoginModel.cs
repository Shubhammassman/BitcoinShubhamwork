﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.ComponentModel.DataAnnotations;

namespace BitCoinMassman.Models
{
    public class AdminLoginModel
    {
        [Required]
        [Display(Name = "User Name")]
        public string UserName { get; set; }

        [Required]
        [Display(Name = "LoginTypeId")]
        public string LoginTypeId { get; set; }

        [Required]
        [EmailAddress]
        [Display(Name = "User Id")]
        public string UserId { get; set; }



        [Required(ErrorMessage = "Please enter old password...")]
        [DataType(DataType.Password)]
        public string OldPassword { get; set; }




        [Required(ErrorMessage = "Please enter new password...")]
        [StringLength(100, ErrorMessage = "The {0} must be at least {2} characters long.", MinimumLength = 6)]
        [DataType(DataType.Password)]
        [Display(Name = "Password")]
        public string AdminPwd { get; set; }




        [Required(ErrorMessage = "Please confirm your password...")]
        [DataType(DataType.Password)]
        [Compare("AdminPwd", ErrorMessage = "The password and confirmation password do not match.")]
        [Display(Name = "Confirm Password")]
        public string ConfirmAdminPwd { get; set; }


    }
}