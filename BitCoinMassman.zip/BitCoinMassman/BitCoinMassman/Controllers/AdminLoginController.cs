﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;
using BitCoinMassman.Models;
using BitCoinMassman.DAL;
using System.Data;
using System.Data.SqlClient;
using BitCoinMassman.Service;
using BitCoinMassman.Controllers;
using System.Configuration;


namespace BitCoinMassman.Controllers
{
    public class AdminLoginController : Controller
    {
       
        string constr = ConfigurationManager.ConnectionStrings["Registration"].ToString();
        // GET: AdminLogin
        public ActionResult Index()
        {
            return View();
        }

        // POST: AdminLogin
        [HttpPost]
        [ValidateAntiForgeryToken]
        public ActionResult Index(AdminLoginModel Registrtion)
        {
           
            try
            {
                //if (ModelState.IsValid)
                //{
                        string encryptPwd = "";
                        //if (Registrtion.AdminPwd != null)
                        //{
                        //    encryptPwd = Encrypt_Decrypt.Decrypt(Registrtion.AdminPwd.ToString());
                        //}

                      Registrtion.LoginTypeId = "2";
                      //DataTable dt = Services.MatchAdminLoginID(Registrtion.UserId, Registrtion.AdminPwd);
                      DataTable dt = Services.MatchAdminLoginID(Registrtion);
                      if (dt.Rows.Count> 0)
                      {
                            if (dt.Rows[0]["LoginTypeId"].ToString()== "1")
                            {
                                 return RedirectToAction("Dashboard", "Admin");
                            }
                            if (dt.Rows[0]["LoginTypeId"].ToString() == "2")
                            {
                                return RedirectToAction("Dashboard", "WebUser");
                            }
                     }
                    else
                    {

                        ModelState.AddModelError("", "Invalid login attempt.");
                    }

                //}
                return View();
            }
            catch (Exception ex)
            {

            }
           
            return View();
        }



        // GET: AdminLogin/Create
        public ActionResult CreateAccount()    
        {
            return View();
        }

        // POST: AdminLogin/Create
        [HttpPost]
        public ActionResult CreateAccount(AdminLoginModel Registrtion)
        {


         //if (ModelState.IsValid)
         //  {  
           try
            {
                 
                string status = "";
                Registrtion.LoginTypeId = "2";
                int i = Services.AddAccount(Registrtion);
                if (i > 0)
                {
                    status = "Success";
                    ViewBag.CreationStatus = status;
                    // ViewBag.SM = "updated";
                }
                return View();
            }
            catch (Exception ex)
            {

            }
           
          //}
        return View();
     }






        // GET: AdminLogin/ForgatePassword
        public ActionResult ForgatePassword()
        {
            return View();
        }




        // GET: AdminLogin/ForgatePassword
        [HttpPost]
        public ActionResult ForgatePassword(AdminLoginModel Registrtion)
        {


            //if (ModelState.IsValid)
            //  {  
            try
            {
                string status = "";
                int i = Services.CreateNewpassword(Registrtion); 
                if (i > 0)
                {
                    status = "Success Update";
                    ViewBag.CreationStatus = status;
                    // ViewBag.SM = "updated";
                }
                return View();
            }
            catch (Exception ex)
            {
                return View(@"~\Views\AdminLogin\CreateAccount.cshtml");
            }
           
        }
        //}


        // GET: AdminLogin/Details/5
        public ActionResult Details(int id)
        {
            return View();
        }






        // GET: AdminLogin/Edit/5
        public ActionResult Edit(int id)
        {
            return View();
        }

        // POST: AdminLogin/Edit/5
        [HttpPost]
        public ActionResult Edit(int id, FormCollection collection)
        {
            try
            {
                // TODO: Add update logic here

                return RedirectToAction("Index");
            }
            catch
            {
                return View();
            }
        }

        // GET: AdminLogin/Delete/5
        public ActionResult Delete(int id)
        {
            return View();
        }

        // POST: AdminLogin/Delete/5
        [HttpPost]
        public ActionResult Delete(int id, FormCollection collection)
        {
            try
            {
                // TODO: Add delete logic here

                return RedirectToAction("Index");
            }
            catch
            {
                return View();
            }
        }
    }
}
