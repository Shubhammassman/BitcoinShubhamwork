﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;

namespace BitCoinMassman.Controllers
{
    public class WebUserController : Controller
    {
        //USE GET: WebUser
        public ActionResult Index()
        {
            return View();
        }


        //USE GET: WebUser Dashboard
        public ActionResult Dashboard()
        {
            
            return View();
        }



        //USE GET: WebUser/DDLTypeBitCoins
        public JsonResult DDLTypeBitCoins(long? CategoryTypeId)
        {
            //var subcategory = new SelectList(db.Categories.Where(m => m.CategoryTypeId == CategoryTypeId).ToList(), "CategoryId", "CategoryName");
            // return Json(subcategory, JsonRequestBehavior.AllowGet);
            return Json("","");
        }
       

        // GET: WebUser/Details/5
        public ActionResult Details(int id)
        {
            return View();
        }

        // GET: WebUser/Create
        public ActionResult Create()
        {
            return View();
        }

        // POST: WebUser/Create
        [HttpPost]
        public ActionResult Create(FormCollection collection)
        {
            try
            {
                // TODO: Add insert logic here

                return RedirectToAction("Index");
            }
            catch
            {
                return View();
            }
        }

        // GET: WebUser/Edit/5
        public ActionResult Edit(int id)
        {
            return View();
        }

        // POST: WebUser/Edit/5
        [HttpPost]
        public ActionResult Edit(int id, FormCollection collection)
        {
            try
            {
                // TODO: Add update logic here

                return RedirectToAction("Index");
            }
            catch
            {
                return View();
            }
        }

        // GET: WebUser/Delete/5
        public ActionResult Delete(int id)
        {
            return View();
        }

        // POST: WebUser/Delete/5
        [HttpPost]
        public ActionResult Delete(int id, FormCollection collection)
        {
            try
            {
                // TODO: Add delete logic here

                return RedirectToAction("Index");
            }
            catch
            {
                return View();
            }
        }
    }
}
