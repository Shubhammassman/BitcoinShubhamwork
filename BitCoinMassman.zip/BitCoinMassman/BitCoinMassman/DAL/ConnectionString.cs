﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Data;
using System.Data.SqlClient;

namespace BitCoinMassman.DAL
{
    public  class ConnectionString
    {

        public  SqlConnection conobj = new SqlConnection("Data Source=DESKTOP-S63VG3U\\SHUBHAMSINGH; Initial Catalog=BITCOIN; User ID=sa; Password=sks726; Integrated Security=False");

    }
}