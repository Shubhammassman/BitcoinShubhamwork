﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Data;
using System.Data.SqlClient;
using BitCoinMassman.DAL;
using BitCoinMassman.Models;
using System.Configuration;
using BitCoinMassman.Service;



namespace BitCoinMassman.Service
{
    public class Services
    {



        static   string   constr = ConfigurationManager.ConnectionStrings["Registration"].ToString();
       
        public static int AddAccount(AdminLoginModel model)
        {

            try
            {
               
                int UP;
                using (SqlConnection con = new SqlConnection(constr))
                {

                    using (SqlCommand cmd = new SqlCommand("CreateAccountBitCoin", con))
                    {
                        if (con.State == System.Data.ConnectionState.Open) { con.Close(); }

                        con.Open();
                        cmd.CommandType = CommandType.StoredProcedure;
                        cmd.Parameters.AddWithValue("@Mode", "Insert");
                        cmd.Parameters.AddWithValue("@UserName", model.UserName);
                        cmd.Parameters.AddWithValue("@UserID", model.UserId);
                        cmd.Parameters.AddWithValue("@UserPassword", Encrypt_Decrypt.Encrypt(model.AdminPwd));
                        cmd.Parameters.AddWithValue("@ISActive", "1");
                        cmd.Parameters.AddWithValue("@CreditDate", System.DateTime.Today);
                        cmd.Parameters.AddWithValue("@LoginTypeID", model.LoginTypeId);
                        UP = cmd.ExecuteNonQuery();

                    }

                }
                return UP;
            }
            catch (Exception ex)
            {
                return 0;
          }
       }




        public static int CreateNewpassword(AdminLoginModel model)
        {

            try
            {

                int UP;
                using (SqlConnection con = new SqlConnection(constr))
                {

                    using (SqlCommand cmd = new SqlCommand("CreateAccountBitCoin", con))
                    {
                        if (con.State == System.Data.ConnectionState.Open) { con.Close(); }
                        con.Open();
                        cmd.CommandType = CommandType.StoredProcedure;
                        cmd.Parameters.AddWithValue("@Mode", "UpdatePassword");
                        cmd.Parameters.AddWithValue("@UserID", model.UserId);
                        cmd.Parameters.AddWithValue("@OldPassword", Encrypt_Decrypt.Encrypt(model.OldPassword));
                        cmd.Parameters.AddWithValue("@UserPassword", Encrypt_Decrypt.Encrypt(model.AdminPwd));
                        cmd.Parameters.AddWithValue("@ISActive", "0");
                        cmd.Parameters.AddWithValue("@ModifyDate", System.DateTime.Today);
                        UP = cmd.ExecuteNonQuery();
                        model.UserId.Clone();
                        model.OldPassword.Clone();
                        model.AdminPwd.Clone();
                    }

                }
                return UP;
            }
            catch (Exception ex)
            {
                return 0;
            }
        }


        static DataTable dt;
        public  static  DataTable MatchAdminLoginID(AdminLoginModel Registrtion)
        {

            try
            {
                

                using (SqlConnection con = new SqlConnection(constr))
                {

                    using (SqlCommand cmd = new SqlCommand("CreateAccountBitCoin", con))
                    {
                        if (con.State == System.Data.ConnectionState.Open) { con.Close(); }
                        con.Open();
                        cmd.CommandType = CommandType.StoredProcedure;
                        cmd.Parameters.AddWithValue("@Mode", "MatchAdminLoginID");
                        cmd.Parameters.AddWithValue("@UserID", Registrtion.UserId);
                        cmd.Parameters.AddWithValue("@LoginTypeID", Registrtion.LoginTypeId);
                        cmd.Parameters.AddWithValue("@UserPassword", Registrtion.AdminPwd);
                        SqlDataAdapter da = new SqlDataAdapter(cmd);
                        DataSet ds = new DataSet();
                        da.Fill(ds);
                        dt = ds.Tables[0];
                        con.Close();
                        
                    }
                   
                }
                
            }
            catch (Exception ex)
            {

            }
            return dt;
        }

    }
 }
