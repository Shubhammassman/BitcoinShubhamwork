﻿



$(document).ready(function () {
    var BitCoinsId = $(this).val();
    $.ajax({
        type: "POST",
        url: "Index.aspx/GetCountriesName",
        dataType: "json",
        contentType: "application/json",
        data: '{name: "abc" }',
        data: { BitCoinsId: BitCoinsId },
        success: function (BitCoinsData)
        {
            var select = $("#ddBitCoins");
            select.empty();
            select.append($('<option/>', {
                value: 0,
                text: "Select a subcategorie"
            }));
            $.each(BitCoinsData, function (index, itemData) {
                select.append($('<option/>', {
                    value: itemData.Value,
                    text: itemData.Text
                }));
            });
        }
    });
})









//  @Html.DropDownListFor(Model => Model.subcategories, new SelectList(Enumerable.Empty<SelectListItem>(), "subcatId", "Subcategoryname"),
//               "Select a subcategorie", new { id = "ddState" })


//<script type="text/javascript">
//        $(document).ready(function () {
//            $("#dd_Country").change(function () {
//                var categoryId = $(this).val();
//                $.getJSON("../CascadeDropDownLists/LoadSubCatBycategoryId", { categoryId: categoryId },
//                    function (classesData) {
//                        var select = $("#ddState");
//                        select.empty();
//                        select.append($('<option/>', {
//                            value: 0,
//                            text: "Select a subcategorie"
//                        }));
//                        $.each(classesData, function (index, itemData) {
//                            select.append($('<option/>', {
//                                value: itemData.Value,
//                                text: itemData.Text
//                            }));
//                        });
//                    });
//            });
//        });
//</script>